//Define an angular module for our app
var targetCaseStudy = angular.module('targetCaseStudy', []);
 
targetCaseStudy.config(['$routeProvider',
  function($routeProvider, $locationProvider) {
    $routeProvider.
      when('/ShowProductDetails/:productId', {
        templateUrl: 'templates/show_product_detail.html',
        controller: 'ShowProductDetailsController'
    }).
      when('/ShowAllProducts', {
        templateUrl: 'templates/show_all_products.html',
        controller: 'ShowProductController'
      }).
      when('/ShowProductByCategory', {
          templateUrl: 'templates/show_products_by_cat.html',
          controller: 'ShowProductController'
        }).
        when('/ShowProductByCategory/:cat', {
            templateUrl: 'templates/show_products_category.html',
            controller: 'ShowProductCatController'
          }).
          when('/CreateNewProduct', {
              templateUrl: 'templates/create_product_detail.html',
              controller: 'CreateProductDetailsController'
            }).
      otherwise({
        redirectTo: '/ShowAllProducts'
      });
}]);

/**
 * This controller again call the factory method getProductDetails, where we this controller 
 * provide the product id and call webservices to get related data for this product.
 * 
 */ 
targetCaseStudy.controller('ShowProductCatController', function($scope, $routeParams, productFactory, $location) {
     
	$scope.productCategoryList = {};
	$scope.category = $routeParams.cat;
	getProductCategory($scope.category);
    function getProductCategory(category) {
    	productFactory.getProductCategory(category).success(function(response) {
    		$scope.productCategoryList = response;
    	}).error(function(error){
    		$scope.status = "Error Retriving data";
    	});
    } 
    
    $scope.deleteProduct = function (productId) {
    	deleteProduct(productId);
    }
    
    function deleteProduct(productId) {
    	productFactory.deleteProduct(productId).success(function(response) {
    		if(response.successCode == '200') {
    			$location.path('#ShowAllProducts');
    		}
    	}).error(function(error){
    		$scope.status = "Error Retriving data";
    	});
    	
    }
});
 
/**
 * This controller again call the factory method getProductDetails, where we this controller 
 * provide the product id and call webservices to get related data for this product.
 * 
 */ 
targetCaseStudy.controller('ShowProductDetailsController', function($scope, $routeParams, productFactory) {
     
	$scope.product = {};
	$scope.success = true;
	$scope.product_Id = $routeParams.productId;
    getProductDetails($scope.product_Id);
    function getProductDetails(product_Id) {
    	productFactory.getProductDetails(product_Id).success(function(response) {
    		$scope.product = response;
    	}).error(function(error){
    		$scope.status = "Error Retriving data";
    	});
    } 
    
    $scope.submitFormData = function () {
    	productFactory.updateProduct($scope.product, $scope.product_Id).success(function (response) {
    		if(response.successCode == '200') {
    			$scope.success = false;	
    		}
    	}).
    	error(function(error) {
    		alert("Error Occurred:" + error.message);
    	});
    };
});

/**
 * This controller again call the factory method getProductDetails, where we this controller 
 * provide the product id and call webservices to get related data for this product.
 * 
 */ 
targetCaseStudy.controller('CreateProductDetailsController', function($scope, $routeParams, productFactory, $location) {
     
	$scope.product = {};
	$scope.created = true;
	$scope.submitProductData = function () {
		$scope.submitted = true;
    	if ($scope.form.$valid) {
	    	productFactory.createProduct($scope.product).success(function (response) {
	    		if(response.successCode == '200') {
	    			$location.path('#ShowAllProducts');
	    			$scope.created = false;
	    		}
	    		
	    	}).
	    	error(function(error) {
	    		alert("Error Occurred:" + error.message);
	    	});
    	}
    };
});
 
/**
 * ShowProductController is used to get all the product from the server using factory
 * method getAllProductInfo and then push into the productlist array, later we use this array
 * to display all the product in a table.
 */ 
targetCaseStudy.controller('ShowProductController', function($scope, productFactory, $location) {
 
    $scope.productList = {};
  //$scope.data = [{"name":"Bell","id":"K0H 2V5"},{"name":"Octavius","id":"X1E 6J0"},{"name":"Alexis","id":"N6E 1L6"},{"name":"Colton","id":"U4O 1H4"},{"name":"Abdul","id":"O9Z 2Q8"},{"name":"Ian","id":"Q7W 8M4"},{"name":"Eden","id":"H8X 5E0"},{"name":"Britanney","id":"I1Q 1O1"},{"name":"Ulric","id":"K5J 1T0"},{"name":"Geraldine","id":"O9K 2M3"},{"name":"Hamilton","id":"S1D 3O0"},{"name":"Melissa","id":"H9L 1B7"},{"name":"Remedios","id":"Z3C 8P4"},{"name":"Ignacia","id":"K3B 1Q4"},{"name":"Jaime","id":"V6O 7C9"},{"name":"Savannah","id":"L8B 8T1"},{"name":"Declan","id":"D5Q 3I9"},{"name":"Skyler","id":"I0O 4O8"},{"name":"Lawrence","id":"V4K 0L2"},{"name":"Yael","id":"R5E 9D9"},{"name":"Herrod","id":"V5W 6L3"},{"name":"Lydia","id":"G0E 2K3"},{"name":"Tobias","id":"N9P 2V5"},{"name":"Wing","id":"T5M 0E2"},{"name":"Callum","id":"L9P 3W5"},{"name":"Tiger","id":"R9A 4E4"},{"name":"Summer","id":"R4B 4Q4"},{"name":"Beverly","id":"M5E 4V4"},{"name":"Xena","id":"I8G 6O1"},{"name":"Yael","id":"L1K 5C3"},{"name":"Stacey","id":"A4G 1S4"},{"name":"Marsden","id":"T1J 5J3"},{"name":"Uriah","id":"S9S 8I7"},{"name":"Kamal","id":"Y8Z 6X0"},{"name":"MacKensie","id":"W2N 7P9"},{"name":"Amelia","id":"X7A 0U3"},{"name":"Xavier","id":"B8I 6C9"},{"name":"Whitney","id":"H4M 9U2"},{"name":"Linus","id":"E2W 7U1"},{"name":"Aileen","id":"C0C 3N2"},{"name":"Keegan","id":"V1O 6X2"},{"name":"Leonard","id":"O0L 4M4"},{"name":"Honorato","id":"F4M 8M6"},{"name":"Zephr","id":"I2E 1T9"},{"name":"Karen","id":"H8W 4I7"},{"name":"Orlando","id":"L8R 0U4"},{"name":"India","id":"N8M 8F4"},{"name":"Luke","id":"Q4Y 2Y8"},{"name":"Sophia","id":"O7F 3F9"},{"name":"Faith","id":"B8P 1U5"},{"name":"Dara","id":"J4A 0P3"},{"name":"Caryn","id":"D5M 8Y8"},{"name":"Colton","id":"A4Q 2U1"},{"name":"Kelly","id":"J2E 2L3"},{"name":"Victor","id":"H1V 8Y5"},{"name":"Clementine","id":"Q9R 4G8"},{"name":"Dale","id":"Q1S 3I0"},{"name":"Xavier","id":"Z0N 0L5"},{"name":"Quynn","id":"D1V 7B8"},{"name":"Christine","id":"A2X 0Z8"},{"name":"Matthew","id":"L1H 2I4"},{"name":"Simon","id":"L2Q 7V7"},{"name":"Evan","id":"Z8Y 6G8"},{"name":"Zachary","id":"F4K 8V9"},{"name":"Deborah","id":"I0D 4J6"},{"name":"Carl","id":"X7H 3J3"},{"name":"Colin","id":"C8P 0O1"},{"name":"Xenos","id":"K3S 1H5"},{"name":"Sonia","id":"W9C 0N3"},{"name":"Arsenio","id":"B0M 2G6"},{"name":"Angela","id":"N9X 5O7"},{"name":"Cassidy","id":"T8T 0Q5"},{"name":"Sebastian","id":"Y6O 0A5"},{"name":"Bernard","id":"P2K 0Z5"},{"name":"Kerry","id":"T6S 4T7"},{"name":"Uriel","id":"K6G 5V2"},{"name":"Wanda","id":"S9G 2E5"},{"name":"Drake","id":"G3G 8Y2"},{"name":"Mia","id":"E4F 4V8"},{"name":"George","id":"K7Y 4L4"},{"name":"Blair","id":"Z8E 0F0"},{"name":"Phelan","id":"C5Z 0C7"},{"name":"Margaret","id":"W6F 6Y5"},{"name":"Xaviera","id":"T5O 7N5"},{"name":"Willow","id":"W6K 3V0"},{"name":"Alden","id":"S2M 8C1"},{"name":"May","id":"L5B 2H3"},{"name":"Amaya","id":"Q3B 7P8"},{"name":"Julian","id":"W6T 7I6"},{"name":"Colby","id":"N3Q 9Z2"},{"name":"Cole","id":"B5G 0V7"},{"name":"Lana","id":"O3I 2W9"},{"name":"Dieter","id":"J4A 9Y6"},{"name":"Rowan","id":"I7E 9U4"},{"name":"Abraham","id":"S7V 0W9"},{"name":"Eleanor","id":"K7K 9P4"},{"name":"Martina","id":"V0Z 5Q7"},{"name":"Kelsie","id":"R7N 7P2"},{"name":"Hedy","id":"B7E 7F2"},{"name":"Hakeem","id":"S5P 3P6"}];
    $scope.viewby = 3;
    $scope.currentPage = 4;
    $scope.itemsPerPage = $scope.viewby;
    $scope.maxSize = 5; //Number of pager buttons to show
    
    getAllProduct();
   
    function getAllProduct() {
    	productFactory.getAllProductInfo().success(function(response) {
    		$scope.productList = response.product;
    		$scope.totalItems = $scope.productList.length;
    	}).error(function(error){
    		$scope.status = "Error Retriving data";
    	});
    }
    $scope.deleteProduct = function (productId) {
    	deleteProduct(productId);
    }
    
    function deleteProduct(productId) {
    	productFactory.deleteProduct(productId).success(function(response) {
    		if(response.successCode == '200') {
    			$location.path('#ShowAllProducts');
    		}
    	}).error(function(error){
    		$scope.status = "Error Retriving data";
    	});
    }
    
    $scope.setPage = function (pageNo) {
      $scope.currentPage = pageNo;
    };

  $scope.setItemsPerPage = function(num) {
    $scope.itemsPerPage = num;
    $scope.currentPage = 1; //reset to first paghe
  }
});

/**
 * This is a factory where we produce all the data for our case study. 
 * We use angular js http methods to get data using all the web services
 * available. 
 * <Example>
 * 		http://localhost:8080/TargetCaseStudy/service/products/allproduct
 *  create a factory with the above url and feed data to the appropriate controller.
 */
targetCaseStudy.factory('productFactory', ['$http', function($http) {
	 
    var factory = {};
    
    var baseurl = 'http://localhost:8080/TargetCaseStudy/service/products/';
    factory.getAllProductInfo = function() {
    	return $http.get(baseurl + "productinfo");
    }
    factory.getProductDetails = function(productId) {
    	return $http.get(baseurl + productId);
    }
    
    factory.getProductCategory = function(category) {
    	return $http.get(baseurl + "category/" +category);
    }
    factory.updateProduct = function (product, productId) {
        return $http.put(baseurl + productId, product);
    };
    factory.createProduct = function (product) {
        return $http.post(baseurl+"createproduct", product);
    };
    factory.deleteProduct = function (productId) {
        return $http.delete(baseurl+ productId);
    };
    return factory;
}])

targetCaseStudy.filter('unique', function() {
   return function(collection, keyname) {
      var output = [], 
          keys = [];

      angular.forEach(collection, function(item) {
          var key = item[keyname].toLowerCase();
          if(keys.indexOf(key) === -1) {
              keys.push(key);
              output.push(item);
          }
      });
      return output;
   };
});